# TSB Macro - Roblox The Strongest Battleground
### Android Overlay Macro App

---

## 📱 Features

| Feature | Description |
|---|---|
| Floating Button | Blue ⓜ button appears over any app including Roblox |
| Short Tap | Toggle macro ON (green) / OFF (blue) |
| Long Press (0.6s) | Opens the full settings menu |
| Drag to Move | Drag the button anywhere on screen |
| 🔒 Lock Position | Locks button so it can't be accidentally moved |
| M1 Spam | Auto-taps the M1 (basic attack) at adjustable speed |
| Auto Combo | Executes combo loops with pause timing |
| Auto Ultimate | Fires ult automatically after combo delay |
| Auto Dodge | Periodic dodge/roll automation |
| Lock Target | Keeps targeting the current enemy |

---

## 🔨 How to Build

### Requirements
- Android Studio Hedgehog or later
- Android SDK 26+
- JDK 17

### Steps
1. Open Android Studio → **Open** → select the `RobloxMacro` folder
2. Let Gradle sync complete
3. Go to **Build → Build Bundle(s) / APK(s) → Build APK(s)**
4. APK will be in: `app/build/outputs/apk/debug/app-debug.apk`
5. Transfer to your Android phone and install (enable Unknown Sources in settings)

---

## 📲 How to Use

1. Open **TSB Macro** app
2. Tap **Grant Overlay Permission** → enable "Allow display over other apps"
3. Tap **▶ Start Overlay**
4. Open **Roblox** and join The Strongest Battleground
5. **Tap** the blue ⓜ button → turns green = macro running
6. **Long press** ⓜ → settings menu appears
7. Adjust speeds, toggle features with switches and sliders
8. Enable **🔒 Lock Button Position** so you don't move it accidentally
9. Return to the TSB Macro app and tap **■ Stop Overlay** when done

---

## ⚠️ Note on Auto-Tap
Full automated tapping requires Android **Accessibility Service** or **root** permissions.
The macro loop structure is implemented and ready — to complete the auto-tap injection:
- Add an `AccessibilityService` class that dispatches `GestureDescription` taps
- Or use root-based `input tap x y` shell commands

The overlay UI, settings, button lock, and all configuration logic is fully functional as-is.

---

## 📁 Project Structure
```
RobloxMacro/
├── app/src/main/
│   ├── AndroidManifest.xml          # Permissions + service declaration
│   ├── java/com/robloxmacro/tsb/
│   │   ├── MainActivity.java        # Permission flow + start/stop UI
│   │   ├── OverlayService.java      # Core: floating button, menu, macro loop
│   │   └── MacroConfig.java         # All configurable settings
│   └── res/
│       ├── layout/activity_main.xml # Main screen layout
│       ├── values/styles.xml        # Dark theme
│       └── drawable/ic_launcher.xml # App icon
└── build.gradle / settings.gradle  # Gradle build config
```
