package com.robloxmacro.tsb;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.Context;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class OverlayService extends Service {

    private WindowManager windowManager;
    private View floatButton;
    private View menuPanel;
    private WindowManager.LayoutParams floatParams;
    private WindowManager.LayoutParams menuParams;

    private MacroConfig config = new MacroConfig();
    private Handler macroHandler = new Handler(Looper.getMainLooper());
    private Runnable macroRunnable;

    // Long press detection
    private Handler longPressHandler = new Handler(Looper.getMainLooper());
    private boolean isLongPress = false;
    private static final long LONG_PRESS_DURATION = 600;

    // Drag tracking
    private int initialX, initialY;
    private float initialTouchX, initialTouchY;
    private boolean isDragging = false;
    private static final int DRAG_THRESHOLD = 10;

    // Lock position feature
    private boolean positionLocked = false;

    private static final String CHANNEL_ID = "TSBMacroChannel";

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(1, buildNotification());
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createFloatButton();
    }

    private void createFloatButton() {
        // ---- Floating Button ----
        floatButton = new View(this);
        floatButton.setBackgroundColor(Color.parseColor("#CC1A1A2E"));

        // Draw a custom circle button appearance
        android.graphics.drawable.GradientDrawable shape = new android.graphics.drawable.GradientDrawable();
        shape.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        shape.setColor(Color.parseColor("#FF0A84FF"));
        shape.setStroke(4, Color.WHITE);
        floatButton.setBackground(shape);

        int btnSize = dpToPx(60);

        floatParams = new WindowManager.LayoutParams(
                btnSize, btnSize,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        floatParams.gravity = Gravity.TOP | Gravity.START;
        floatParams.x = config.buttonX;
        floatParams.y = config.buttonY;

        windowManager.addView(floatButton, floatParams);

        // Add "M" text label on top
        android.widget.TextView label = new android.widget.TextView(this);
        label.setText("M");
        label.setTextColor(Color.WHITE);
        label.setTextSize(18);
        label.setGravity(Gravity.CENTER);
        WindowManager.LayoutParams labelParams = new WindowManager.LayoutParams(
                btnSize, btnSize,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT);
        labelParams.gravity = Gravity.TOP | Gravity.START;
        labelParams.x = config.buttonX;
        labelParams.y = config.buttonY;
        windowManager.addView(label, labelParams);

        floatButton.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    isDragging = false;
                    initialX = floatParams.x;
                    initialY = floatParams.y;
                    initialTouchX = event.getRawX();
                    initialTouchY = event.getRawY();
                    isLongPress = false;
                    if (!positionLocked) {
                        longPressHandler.postDelayed(() -> {
                            isLongPress = true;
                            vibrateDevice();
                            showMenu();
                        }, LONG_PRESS_DURATION);
                    } else {
                        longPressHandler.postDelayed(() -> {
                            isLongPress = true;
                            vibrateDevice();
                            showMenu();
                        }, LONG_PRESS_DURATION);
                    }
                    return true;

                case MotionEvent.ACTION_MOVE:
                    float dx = event.getRawX() - initialTouchX;
                    float dy = event.getRawY() - initialTouchY;
                    if (!isDragging && (Math.abs(dx) > DRAG_THRESHOLD || Math.abs(dy) > DRAG_THRESHOLD)) {
                        isDragging = true;
                        longPressHandler.removeCallbacksAndMessages(null);
                    }
                    if (isDragging && !positionLocked) {
                        floatParams.x = initialX + (int) dx;
                        floatParams.y = initialY + (int) dy;
                        labelParams.x = floatParams.x;
                        labelParams.y = floatParams.y;
                        windowManager.updateViewLayout(floatButton, floatParams);
                        windowManager.updateViewLayout(label, labelParams);
                    }
                    return true;

                case MotionEvent.ACTION_UP:
                    longPressHandler.removeCallbacksAndMessages(null);
                    if (!isDragging && !isLongPress) {
                        // Short tap = toggle macro
                        toggleMacro();
                        updateButtonColor();
                    }
                    if (!positionLocked) {
                        config.buttonX = floatParams.x;
                        config.buttonY = floatParams.y;
                    }
                    return true;
            }
            return false;
        });
    }

    private void updateButtonColor() {
        android.graphics.drawable.GradientDrawable shape = new android.graphics.drawable.GradientDrawable();
        shape.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        shape.setColor(config.macroRunning ? Color.parseColor("#FF30D158") : Color.parseColor("#FF0A84FF"));
        shape.setStroke(4, config.macroRunning ? Color.parseColor("#FFFFD60A") : Color.WHITE);
        floatButton.setBackground(shape);
    }

    private void toggleMacro() {
        config.macroRunning = !config.macroRunning;
        if (config.macroRunning) {
            startMacroLoop();
            Toast.makeText(this, "🟢 Macro ON", Toast.LENGTH_SHORT).show();
        } else {
            stopMacroLoop();
            Toast.makeText(this, "🔴 Macro OFF", Toast.LENGTH_SHORT).show();
        }
    }

    private void startMacroLoop() {
        macroRunnable = new Runnable() {
            @Override
            public void run() {
                if (!config.macroRunning) return;
                // Simulate macro steps (accessibility/auto-tap requires AccessibilityService)
                // Here we show the logic flow; actual tapping needs AccessibilityService or root
                performMacroStep();
                macroHandler.postDelayed(this, config.m1SpeedMs);
            }
        };
        macroHandler.post(macroRunnable);
    }

    private void performMacroStep() {
        // In a real implementation this dispatches taps via AccessibilityService
        // For now logs the action sequence
        if (config.m1Spam) {
            // tap M1 button position
        }
        if (config.autoCombo) {
            // execute combo pattern
        }
        if (config.autoUlt) {
            // tap ult after delay
        }
    }

    private void stopMacroLoop() {
        if (macroRunnable != null) {
            macroHandler.removeCallbacks(macroRunnable);
        }
    }

    // ---- MENU PANEL ----
    private void showMenu() {
        if (menuPanel != null) {
            dismissMenu();
            return;
        }

        menuPanel = buildMenuView();
        menuParams = new WindowManager.LayoutParams(
                dpToPx(300), WindowManager.LayoutParams.WRAP_CONTENT,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        menuParams.gravity = Gravity.CENTER;
        windowManager.addView(menuPanel, menuParams);
    }

    private View buildMenuView() {
        // Root container
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dpToPx(16), dpToPx(16), dpToPx(16), dpToPx(16));
        root.setBackgroundColor(Color.parseColor("#F01A1A2E"));

        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setCornerRadius(dpToPx(16));
        bg.setColor(Color.parseColor("#F0141432"));
        bg.setStroke(2, Color.parseColor("#FF0A84FF"));
        root.setBackground(bg);

        // Title
        TextView title = new TextView(this);
        title.setText("⚔️  TSB Macro Settings");
        title.setTextColor(Color.parseColor("#FF0A84FF"));
        title.setTextSize(16);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, dpToPx(12));
        root.addView(title);

        // --- M1 Spam ---
        root.addView(makeSwitchRow("M1 Spam", config.m1Spam, checked -> config.m1Spam = checked));
        root.addView(makeSeekRow("M1 Speed (ms)", 50, 500, config.m1SpeedMs, val -> config.m1SpeedMs = val));

        // --- Auto Combo ---
        root.addView(makeSwitchRow("Auto Combo", config.autoCombo, checked -> config.autoCombo = checked));
        root.addView(makeSeekRow("Combo Pause (ms)", 40, 300, config.comboPauseMs, val -> config.comboPauseMs = val));
        root.addView(makeSeekRow("Combo Repeats", 1, 10, config.comboRepeatCount, val -> config.comboRepeatCount = val));

        // --- Auto Ult ---
        root.addView(makeSwitchRow("Auto Ultimate", config.autoUlt, checked -> config.autoUlt = checked));
        root.addView(makeSeekRow("Ult Delay (ms)", 100, 2000, config.ultDelayMs, val -> config.ultDelayMs = val));

        // --- Auto Dodge ---
        root.addView(makeSwitchRow("Auto Dodge", config.autoDodge, checked -> config.autoDodge = checked));

        // --- Lock Target ---
        root.addView(makeSwitchRow("Lock Target", config.lockTarget, checked -> config.lockTarget = checked));

        // --- Lock Button Position ---
        root.addView(makeSwitchRow("🔒 Lock Button Position", positionLocked, checked -> {
            positionLocked = checked;
            Toast.makeText(this, positionLocked ? "Button position locked!" : "Button position unlocked!", Toast.LENGTH_SHORT).show();
        }));

        // --- Close button ---
        android.widget.Button closeBtn = new android.widget.Button(this);
        closeBtn.setText("✕  Close");
        closeBtn.setBackgroundColor(Color.parseColor("#FF0A84FF"));
        closeBtn.setTextColor(Color.WHITE);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dpToPx(12);
        closeBtn.setLayoutParams(lp);
        closeBtn.setOnClickListener(v -> dismissMenu());
        root.addView(closeBtn);

        // Wrap in ScrollView
        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        return scroll;
    }

    interface BoolCallback { void onChanged(boolean val); }
    interface IntCallback { void onChanged(int val); }

    private View makeSwitchRow(String label, boolean initial, BoolCallback cb) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dpToPx(6), 0, dpToPx(6));

        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(13);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        tv.setLayoutParams(lp);
        row.addView(tv);

        Switch sw = new Switch(this);
        sw.setChecked(initial);
        sw.setOnCheckedChangeListener((b, isChecked) -> cb.onChanged(isChecked));
        row.addView(sw);
        return row;
    }

    private View makeSeekRow(String label, int min, int max, int current, IntCallback cb) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(0, dpToPx(4), 0, dpToPx(4));

        TextView tv = new TextView(this);
        tv.setText(label + ": " + current);
        tv.setTextColor(Color.parseColor("#FFAAAACC"));
        tv.setTextSize(12);
        col.addView(tv);

        SeekBar seek = new SeekBar(this);
        seek.setMax(max - min);
        seek.setProgress(current - min);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                int val = progress + min;
                tv.setText(label + ": " + val);
                cb.onChanged(val);
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });
        col.addView(seek);
        return col;
    }

    private void dismissMenu() {
        if (menuPanel != null) {
            windowManager.removeView(menuPanel);
            menuPanel = null;
        }
    }

    private void vibrateDevice() {
        Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        if (v != null) v.vibrate(80);
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "TSB Macro Service", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Running macro overlay");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new Notification.Builder(this, CHANNEL_ID);
        } else {
            builder = new Notification.Builder(this);
        }
        return builder
                .setContentTitle("TSB Macro Active")
                .setContentText("Tap the overlay button to toggle macro. Long press to configure.")
                .setSmallIcon(android.R.drawable.ic_menu_manage)
                .build();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        stopMacroLoop();
        if (floatButton != null) windowManager.removeView(floatButton);
        dismissMenu();
    }
}
