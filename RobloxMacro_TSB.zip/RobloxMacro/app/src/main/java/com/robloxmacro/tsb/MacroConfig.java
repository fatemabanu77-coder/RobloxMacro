package com.robloxmacro.tsb;

public class MacroConfig {
    // Combo settings
    public boolean autoCombo = true;
    public int comboPauseMs = 80;       // delay between combo hits
    public int comboRepeatCount = 3;    // how many times to repeat combo loop

    // M1 spam settings
    public boolean m1Spam = true;
    public int m1SpeedMs = 100;         // ms between each M1 tap

    // Ultimate / skill timing
    public boolean autoUlt = false;
    public int ultDelayMs = 500;        // delay before ulting after combo

    // Dodge/roll
    public boolean autoDodge = false;
    public int dodgeIntervalMs = 1500;

    // Lock on target
    public boolean lockTarget = true;

    // Button position (saved)
    public int buttonX = 100;
    public int buttonY = 300;

    // Active state
    public boolean macroRunning = false;
}
